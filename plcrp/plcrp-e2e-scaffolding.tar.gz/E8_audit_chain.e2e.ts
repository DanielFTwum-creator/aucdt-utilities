/**
 * E8 — audit log SHA-256 chain integrity.
 *
 * Verifies that the audit log's tamper detection actually works.
 * This test is what gives FR-8.2 ("append-only and SHA-256-chained
 * for tamper detection") any teeth — without an end-to-end test of
 * the detection path, the chain is just decoration.
 *
 * The test:
 *   1. Performs 50 state-changing actions through the UI.
 *   2. Runs audit-verify — expects PASS.
 *   3. Tampers with row 23 directly via the test harness.
 *   4. Runs audit-verify — expects FAIL at row 23.
 *   5. UI surfaces a P1 banner; admin console enters
 *      maintenance-mode-recommended state.
 *
 * The tamper API is gated behind NODE_ENV=test on the server.
 * In production it returns 404.
 */

import { describe, it, beforeAll, afterAll } from 'vitest';
import {
  openScenario,
  closeScenario,
  signIn,
  shot,
  testApi,
  TestContext,
} from './harness';

describe('E8 — audit chain integrity end-to-end', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await openScenario('E8_audit_chain');
  }, 30_000);

  afterAll(async () => {
    await closeScenario(ctx);
  });

  it('writes 50 state-changing actions and chain verifies clean', async () => {
    await signIn(ctx);

    // The fixture's "burst" endpoint runs 50 ingest events synchronously.
    // We use it instead of clicking 50 times for test speed; the actions
    // pass through the same audit code path as UI-driven actions.
    await testApi(ctx, '/api/test/sandbox/burst?n=50&kind=ingest', {
      method: 'POST',
    });

    await ctx.page.click('[data-test="nav-audit"]');
    await ctx.page.waitForSelector('[data-test="audit-log-table"]');
    await shot(ctx, '50-entries-written');

    await ctx.page.click('[data-test="run-audit-verify"]');
    await ctx.page.waitForSelector('[data-test="audit-verify-result"]');
    await shot(ctx, 'verify-clean');

    const status = await ctx.page.$eval(
      '[data-test="audit-verify-result"]',
      (el) => el.getAttribute('data-status')
    );
    if (status !== 'PASS') {
      throw new Error(`Expected verification to PASS, got ${status}`);
    }
  });

  it('detects tampering on row 23 with the correct error message', async () => {
    // Tamper directly via test harness (production has no such endpoint).
    await testApi(ctx, '/api/test/sandbox/audit/tamper?row=23', {
      method: 'POST',
    });
    await shot(ctx, 'tampered');

    await ctx.page.click('[data-test="run-audit-verify"]');
    await ctx.page.waitForSelector('[data-test="audit-verify-result"]');
    await shot(ctx, 'verify-after-tamper');

    const status = await ctx.page.$eval(
      '[data-test="audit-verify-result"]',
      (el) => el.getAttribute('data-status')
    );
    if (status !== 'FAIL') {
      await shot(ctx, 'FAIL_verify_did_not_detect_tamper');
      throw new Error(`Expected FAIL after tamper, got ${status}`);
    }

    const breakRow = await ctx.page.$eval(
      '[data-test="audit-verify-break-row"]',
      (el) => parseInt(el.textContent?.trim() ?? '0', 10)
    );
    if (breakRow !== 23) {
      throw new Error(`Expected break at row 23, got ${breakRow}`);
    }
  });

  it('shows a P1 banner and recommends maintenance mode', async () => {
    await ctx.page.click('[data-test="nav-dashboard"]');
    await ctx.page.waitForSelector('[data-test="dashboard"]');
    await shot(ctx, 'dashboard-after-tamper-detected');

    const bannerText = await ctx.page.$eval(
      '[data-test="severity-banner"]',
      (el) => el.textContent ?? ''
    );
    if (!bannerText.includes('P1')) {
      throw new Error('Expected P1 banner on dashboard after tamper detection');
    }
    if (!bannerText.toLowerCase().includes('maintenance')) {
      throw new Error('Expected maintenance-mode recommendation in banner');
    }
  });

  it('records the verification failure as a meta-audit entry', async () => {
    // The verification itself writes to the chain — tamper detection
    // is a state change worth tracking.
    await ctx.page.click('[data-test="nav-audit"]');
    await ctx.page.waitForSelector('[data-test="audit-log-table"]');

    const entries = await ctx.page.$$eval('[data-test="audit-row"]', (rows) =>
      rows.map((r) => r.textContent ?? '')
    );
    const found = entries.some(
      (e) => e.includes('audit_verify_failed') && e.includes('row=23')
    );
    if (!found) {
      throw new Error(
        'Expected meta-audit entry recording the verification failure at row 23'
      );
    }
  });
});
