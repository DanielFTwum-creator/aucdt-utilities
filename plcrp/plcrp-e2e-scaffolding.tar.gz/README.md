# PLCRP End-to-End Test Scaffolding

This directory contains the Puppeteer test scaffolding referenced in the
**Testing Guide** (`TUC-ICT-PLCRP-TEST-GUIDE-v1.0`) and required by Bulletproof
Directive item 3.2 / Acceptance Criterion **AC-8**.

The full suite specified in the Testing Guide is E1 through E8. Three reference
scenarios are implemented here in detail — the most critical ones, where bugs
have the worst consequences:

| ID | File | What it proves |
|----|------|----------------|
| E2 | `E2_rights_audit_gate.e2e.ts` | NON_COMMERCIAL tracks cannot leak past S2. **The most important test in the suite.** |
| E5 | `E5_human_authorship_gate.e2e.ts` | At least 2 human-authorship elements are required before a track can leave S4. |
| E8 | `E8_audit_chain.e2e.ts` | The SHA-256 audit chain actually detects tampering, not just claims to. |

The remaining scenarios (E1, E3, E4, E6, E7) follow the same pattern as E2 and
E5 — they're stage-gate enforcement tests with the same shape:

1. Open scenario, sign in, navigate to the relevant stage view.
2. Verify the gate's promote/submit button is disabled with a meaningful reason.
3. Verify no override exists in the UI.
4. Verify direct API bypass returns the correct error code.
5. Verify the denied attempt is recorded in the audit log.

To finish the suite, copy `E2_rights_audit_gate.e2e.ts` and adapt the fixture
name, the gate selector, and the expected disabled-reason string. The test
harness in `harness.ts` is generic enough to support all eight scenarios
without modification.

## Running locally

```bash
# In one terminal, bring up the test stack
docker compose -f docker-compose.test.yml up -d
pnpm --filter @plcrp/web dev

# In another terminal, run the tests
pnpm test:e2e                           # all scenarios, headless
pnpm test:e2e -- E2_rights_audit_gate   # just one scenario
PLCRP_E2E_HEADED=1 pnpm test:e2e        # watch the browser
```

## Server-side requirements

The harness assumes the server exposes test-only endpoints behind
`NODE_ENV=test`:

- `GET /api/test/sandbox/reset?fixture=<name>` — drops and recreates the
  sandbox schema, seeded from `apps/api/test/fixtures/<name>.json`
- `POST /api/test/sandbox/burst?n=<int>&kind=<event-kind>` — generates N
  state-changing events in one request (test-speed optimisation)
- `POST /api/test/sandbox/audit/tamper?row=<int>` — corrupts the specified
  audit log row to simulate database tampering

These routes MUST return 404 in production. The middleware that gates them is
straightforward; see the parent SRS §4.4 (security) for the reasoning.

## Fixtures

Each scenario references a fixture file by name (the `scenario` argument to
`openScenario`). Fixtures live at `apps/api/test/fixtures/<scenario>.json` and
encode the seed state — pre-existing tracks, releases, audit log entries —
required by the test. Keep fixtures small and explicit; a 50-track fixture
that's mostly there to make numbers look realistic is harder to debug than
a 3-track fixture that exercises only the relevant edge.
