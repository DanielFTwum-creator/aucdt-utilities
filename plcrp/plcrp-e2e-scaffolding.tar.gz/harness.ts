/**
 * PLCRP end-to-end test harness
 * ----------------------------------
 * Shared helpers used by every E*_*.e2e.ts scenario.
 *
 * Conventions:
 *   - One scenario per file, named E{n}_{slug}.e2e.ts
 *   - Each scenario opens a fresh sandbox via /api/test/sandbox/reset
 *   - Each scenario captures a screenshot at every assertion point
 *   - Failures preserve the DOM and any console errors
 */

import { Browser, Page, launch } from 'puppeteer';
import { mkdirSync, existsSync } from 'fs';
import { join } from 'path';

const BASE_URL = process.env.PLCRP_E2E_BASE_URL ?? 'http://localhost:3000';
const ADMIN_EMAIL = process.env.PLCRP_E2E_ADMIN_EMAIL ?? 'test-admin@plcrp.local';
const ADMIN_PASSWORD = process.env.PLCRP_E2E_ADMIN_PASSWORD ?? 'sandbox-only-not-prod';
const HEADLESS = process.env.PLCRP_E2E_HEADED !== '1';

export interface TestContext {
  browser: Browser;
  page: Page;
  scenario: string;
  screenshotDir: string;
  step: number;
}

/**
 * Open a sandboxed browser session against a freshly-reset test database.
 * Every scenario should call this in beforeEach (or at scenario start).
 */
export async function openScenario(scenario: string): Promise<TestContext> {
  const browser = await launch({
    headless: HEADLESS,
    args: ['--no-sandbox', '--disable-dev-shm-usage'],
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 900 });

  const screenshotDir = join(__dirname, 'screenshots', scenario);
  if (!existsSync(screenshotDir)) {
    mkdirSync(screenshotDir, { recursive: true });
  }

  // Surface console errors at the test level — silent failures hide regressions
  page.on('pageerror', (err) => {
    // eslint-disable-next-line no-console
    console.error(`[${scenario}] pageerror:`, err.message);
  });
  page.on('console', (msg) => {
    if (msg.type() === 'error') {
      // eslint-disable-next-line no-console
      console.error(`[${scenario}] console.error:`, msg.text());
    }
  });

  // Reset the sandbox database to the fixture used by this scenario.
  // The /test/sandbox/* routes are gated behind NODE_ENV=test on the server,
  // so this is a no-op against a production deployment — by design.
  await page.goto(`${BASE_URL}/api/test/sandbox/reset?fixture=${scenario}`, {
    waitUntil: 'networkidle0',
  });

  return { browser, page, scenario, screenshotDir, step: 0 };
}

export async function closeScenario(ctx: TestContext): Promise<void> {
  await ctx.browser.close();
}

/**
 * Capture a screenshot. Filename is auto-numbered so order in the gallery
 * matches order of execution.
 */
export async function shot(ctx: TestContext, label: string): Promise<void> {
  ctx.step += 1;
  const filename = `${String(ctx.step).padStart(2, '0')}_${label.replace(/\s+/g, '-')}.png`;
  await ctx.page.screenshot({
    path: join(ctx.screenshotDir, filename) as `${string}.png`,
    fullPage: true,
  });
}

/**
 * Sign in as the test admin. Most scenarios start here.
 */
export async function signIn(ctx: TestContext): Promise<void> {
  await ctx.page.goto(`${BASE_URL}/admin/sign-in`, { waitUntil: 'networkidle0' });
  await ctx.page.type('[data-test="email-input"]', ADMIN_EMAIL);
  await ctx.page.type('[data-test="password-input"]', ADMIN_PASSWORD);
  await Promise.all([
    ctx.page.click('[data-test="sign-in-submit"]'),
    ctx.page.waitForNavigation({ waitUntil: 'networkidle0' }),
  ]);
  // 2FA is bypassed in NODE_ENV=test using the test-admin account.
  await ctx.page.waitForSelector('[data-test="dashboard"]');
  await shot(ctx, 'signed-in');
}

/**
 * Navigate to a stage view in the admin console.
 */
export async function gotoStage(
  ctx: TestContext,
  stage: 'S1' | 'S2' | 'S3' | 'S4' | 'S5' | 'S6'
): Promise<void> {
  await ctx.page.click(`[data-test="nav-${stage}"]`);
  await ctx.page.waitForSelector(`[data-test="stage-${stage}"]`);
  await shot(ctx, `stage-${stage}`);
}

/**
 * Pick a track row by its display name in the current stage view.
 */
export async function clickTrack(ctx: TestContext, displayName: string): Promise<void> {
  await ctx.page.evaluate((name) => {
    const rows = Array.from(
      document.querySelectorAll<HTMLElement>('[data-test="track-row"]')
    );
    const target = rows.find((r) => r.textContent?.includes(name));
    if (!target) {
      throw new Error(`No track row with display name "${name}"`);
    }
    target.click();
  }, displayName);
  await ctx.page.waitForSelector('[data-test="track-detail"]');
}

/**
 * Assert a button exists AND is disabled (the gate-enforcement test pattern).
 * Used by the six stage-gate scenarios.
 */
export async function assertButtonDisabled(
  ctx: TestContext,
  selector: string,
  expectedReason?: string
): Promise<void> {
  const isDisabled = await ctx.page.$eval(selector, (el) =>
    (el as HTMLButtonElement).disabled
  );
  if (!isDisabled) {
    await shot(ctx, 'FAIL_button_not_disabled');
    throw new Error(`Expected ${selector} to be disabled — it was not`);
  }
  if (expectedReason) {
    const tooltip = await ctx.page.$eval(
      `${selector}-reason`,
      (el) => el.textContent?.trim() ?? ''
    );
    if (!tooltip.includes(expectedReason)) {
      await shot(ctx, 'FAIL_wrong_disabled_reason');
      throw new Error(
        `Expected disabled-reason to contain "${expectedReason}", got "${tooltip}"`
      );
    }
  }
  await shot(ctx, `gate-blocked-${selector.replace(/\W+/g, '_')}`);
}

/**
 * Direct API call to the test harness — used to deliberately tamper with
 * the audit log in scenario E8, or to seed state without going through the UI.
 */
export async function testApi<T = unknown>(
  ctx: TestContext,
  path: string,
  init?: RequestInit
): Promise<T> {
  return ctx.page.evaluate(
    async (url, opts) => {
      const r = await fetch(url, opts as RequestInit);
      if (!r.ok) {
        throw new Error(`testApi ${url} -> ${r.status}`);
      }
      return r.json();
    },
    `${BASE_URL}${path}`,
    init as unknown as Record<string, unknown>
  ) as Promise<T>;
}
