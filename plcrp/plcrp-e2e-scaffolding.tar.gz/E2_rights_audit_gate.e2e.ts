/**
 * E2 — S2 → S3 gate: a NON_COMMERCIAL track cannot be promoted.
 *
 * This is the most important test in the suite. If this passes
 * but the underlying enforcement is broken, free-tier Suno tracks
 * could leak into a Spotify release and you would lose your
 * distributor account.
 *
 * The fixture seeds one track:
 *   - source_platform = 'suno'
 *   - source_account_tier = 'free'
 *   - rights_status = 'NON_COMMERCIAL' (auto-assigned by FR-2.1)
 *
 * Test asserts:
 *   1. The "Promote to S3" button is rendered but disabled.
 *   2. Hovering surfaces the reason: "Free-tier source — non-commercial".
 *   3. There is NO override control anywhere in the UI.
 *   4. A direct API call to /tracks/:id/promote returns 403.
 *   5. Audit log records the attempted promotion as a denied action.
 */

import { describe, it, beforeAll, afterAll } from 'vitest';
import {
  openScenario,
  closeScenario,
  signIn,
  gotoStage,
  clickTrack,
  assertButtonDisabled,
  shot,
  testApi,
  TestContext,
} from './harness';

describe('E2 — S2 to S3 gate: NON_COMMERCIAL track is blocked', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await openScenario('E2_rights_audit_gate');
  }, 30_000);

  afterAll(async () => {
    await closeScenario(ctx);
  });

  it('renders the promote button as disabled with the correct reason', async () => {
    await signIn(ctx);
    await gotoStage(ctx, 'S2');
    await clickTrack(ctx, 'Fixture-NonCommercial-Track-001');
    await shot(ctx, 'track-detail-loaded');

    await assertButtonDisabled(
      ctx,
      '[data-test="promote-to-s3"]',
      'Free-tier source'
    );
  });

  it('exposes no override control in the UI', async () => {
    const overrideCount = await ctx.page.$$eval(
      '[data-test*="override"]',
      (els) => els.length
    );
    if (overrideCount > 0) {
      await shot(ctx, 'FAIL_override_present');
      throw new Error(
        `Expected zero override controls on a NON_COMMERCIAL track, found ${overrideCount}`
      );
    }
    await shot(ctx, 'no-override-confirmed');
  });

  it('rejects direct API promotion with 403', async () => {
    // Try to bypass the UI — this is what a hostile actor or buggy script
    // would attempt. The server MUST refuse regardless of UI state.
    const trackId = await ctx.page.$eval(
      '[data-test="track-id"]',
      (el) => el.textContent?.trim() ?? ''
    );

    let status = 0;
    try {
      await testApi(ctx, `/api/tracks/${trackId}/promote?to=S3`, {
        method: 'POST',
      });
    } catch (err) {
      status = parseInt(String(err).match(/-> (\d+)/)?.[1] ?? '0', 10);
    }

    if (status !== 403) {
      await shot(ctx, 'FAIL_api_did_not_return_403');
      throw new Error(`Expected 403, got ${status}`);
    }
  });

  it('records the denied promotion in the audit log', async () => {
    await ctx.page.click('[data-test="nav-audit"]');
    await ctx.page.waitForSelector('[data-test="audit-log-table"]');
    await shot(ctx, 'audit-log');

    const found = await ctx.page.$$eval('[data-test="audit-row"]', (rows) =>
      rows.some(
        (r) =>
          r.textContent?.includes('promote_denied') &&
          r.textContent?.includes('NON_COMMERCIAL')
      )
    );

    if (!found) {
      await shot(ctx, 'FAIL_no_denial_in_audit_log');
      throw new Error(
        'Expected an audit log entry for the denied promotion attempt'
      );
    }
  });
});
