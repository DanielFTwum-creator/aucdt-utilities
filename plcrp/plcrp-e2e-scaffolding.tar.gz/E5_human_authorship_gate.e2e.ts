/**
 * E5 — S4 to S5 gate: human-authorship layer is mandatory.
 *
 * Per FR-4.1 of the SRS, an EnhancedTrack must declare at least
 * TWO of the following before it can be promoted to S5:
 *   - lyrics_human_authored
 *   - vocal_performance_human
 *   - arrangement_daw
 *   - live_instrument_performance
 *
 * This is the gate that protects copyright eligibility AND avoids
 * Spotify's "100% AI-generated" rejection.
 *
 * The fixture seeds one EnhancedTrack with zero human-authorship
 * elements ticked. The test verifies:
 *   1. Promote button disabled with reason "≥ 2 human elements".
 *   2. Tick one element — still disabled, reason updates to "≥ 2".
 *   3. Tick a second element — promote button enables.
 *   4. Submit human-authorship summary (required free-text).
 *   5. Promotion succeeds, EnhancedTrack moves to S5 queue.
 *   6. Each tick is recorded as an audit log entry.
 */

import { describe, it, beforeAll, afterAll } from 'vitest';
import {
  openScenario,
  closeScenario,
  signIn,
  gotoStage,
  clickTrack,
  assertButtonDisabled,
  shot,
  TestContext,
} from './harness';

describe('E5 — S4 to S5 gate: ≥ 2 human-authorship elements required', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await openScenario('E5_human_authorship_gate');
  }, 30_000);

  afterAll(async () => {
    await closeScenario(ctx);
  });

  it('blocks promotion with zero human-authorship elements', async () => {
    await signIn(ctx);
    await gotoStage(ctx, 'S4');
    await clickTrack(ctx, 'Fixture-Enhanced-Track-001');
    await shot(ctx, 'enhance-detail-loaded');
    await assertButtonDisabled(
      ctx,
      '[data-test="promote-to-s5"]',
      'human elements'
    );
  });

  it('still blocks with only one element ticked', async () => {
    await ctx.page.click('[data-test="checkbox-lyrics-human-authored"]');
    await shot(ctx, 'one-element-ticked');
    await assertButtonDisabled(
      ctx,
      '[data-test="promote-to-s5"]',
      'human elements'
    );
  });

  it('enables promotion once two elements are ticked', async () => {
    await ctx.page.click('[data-test="checkbox-arrangement-daw"]');
    await shot(ctx, 'two-elements-ticked');

    const isDisabled = await ctx.page.$eval(
      '[data-test="promote-to-s5"]',
      (el) => (el as HTMLButtonElement).disabled
    );

    if (isDisabled) {
      await shot(ctx, 'FAIL_still_disabled_with_two_elements');
      throw new Error(
        'Promote button should enable once two human-authorship elements are ticked'
      );
    }
  });

  it('requires the human-authorship summary text to be present', async () => {
    // Click promote without filling the summary — should bring up validation
    await ctx.page.click('[data-test="promote-to-s5"]');
    await shot(ctx, 'summary-validation-error');

    const errMsg = await ctx.page.$eval(
      '[data-test="summary-error"]',
      (el) => el.textContent?.trim() ?? ''
    );
    if (!errMsg.includes('summary')) {
      throw new Error(`Expected summary validation error, got "${errMsg}"`);
    }
  });

  it('completes promotion when summary is filled', async () => {
    await ctx.page.type(
      '[data-test="human-authorship-summary"]',
      'Re-wrote the second verse and bridge in patois; tracked live percussion; rebalanced mix in DAW.'
    );
    await shot(ctx, 'summary-filled');

    await Promise.all([
      ctx.page.click('[data-test="promote-to-s5"]'),
      ctx.page.waitForSelector('[data-test="stage-S5"]'),
    ]);
    await shot(ctx, 'promoted-to-s5');
  });

  it('records each authorship tick + the promotion in the audit log', async () => {
    await ctx.page.click('[data-test="nav-audit"]');
    await ctx.page.waitForSelector('[data-test="audit-log-table"]');
    await shot(ctx, 'audit-log-after-promotion');

    const entries = await ctx.page.$$eval(
      '[data-test="audit-row"]',
      (rows) => rows.map((r) => r.textContent ?? '')
    );

    const requiredActions = [
      'human_authorship_ticked:lyrics',
      'human_authorship_ticked:arrangement',
      'enhanced_track_promoted_to_s5',
    ];
    for (const action of requiredActions) {
      if (!entries.some((e) => e.includes(action))) {
        await shot(ctx, `FAIL_missing_audit_${action}`);
        throw new Error(`Expected audit log entry for "${action}"`);
      }
    }
  });
});
